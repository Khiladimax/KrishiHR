package com.krishihr.app.ui.more

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.krishihr.app.AndroidMain
import com.krishihr.app.R
import com.krishihr.app.data.api.RetrofitClient
import com.krishihr.app.utils.Roles
import com.krishihr.app.utils.SessionManager
import com.krishihr.app.utils.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import javax.net.ssl.HttpsURLConnection

// ═══════════════════════════════════════════════════════════════════════════════
// AI FRAGMENT — mirrors ai-voice.html intent logic for Android
// All contact access rules, leave suggestion logic, role-gating carried over.
// ═══════════════════════════════════════════════════════════════════════════════
class AiFragment : Fragment() {

    // ── Speech / TTS state ────────────────────────────────────────────────────
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var micBtn: MaterialButton? = null

    // ── State ─────────────────────────────────────────────────────────────────
    private val chatHistory = mutableListOf<JSONObject>()   // [{role,content}]
    private var allEmployees: JSONArray? = null              // cached
    private var leavePlan: LeavePlan? = null                 // multi-turn planner

    data class LeavePlan(
        val step: String,                       // "type" | "days" | "suggest"
        val types: List<LeaveType> = emptyList(),
        val leaveTypeId: Int = 0,
        val leaveTypeName: String = "",
        val days: Int = 0
    )
    data class LeaveType(val id: Int, val name: String)
    data class BotResponse(val text: String, val chips: List<Chip> = emptyList())
    data class Chip(val label: String, val fragment: Fragment? = null)

    // ── UI refs ───────────────────────────────────────────────────────────────
    private lateinit var messagesContainer: LinearLayout
    private lateinit var scrollView: ScrollView
    private lateinit var inputEt: EditText
    private lateinit var sendBtn: MaterialButton
    private var dp: Float = 0f

    // ── Role helpers ──────────────────────────────────────────────────────────
    private val session by lazy { SessionManager(requireContext()) }
    private val user    by lazy { session.getEmployee() }
    private val role    by lazy { session.getRole() }
    private val userName get() = user?.firstName ?: "there"
    private val isManager   get() = role in listOf(Roles.MANAGER, Roles.TL)
    private val isPrivAdmin get() = role in listOf(Roles.ADMIN, Roles.SUPER_ADMIN, Roles.HR, Roles.ACCOUNTS)
    private val isManagerUp get() = isManager || isPrivAdmin

    // ── MD code — blocks sharing MD contact to non super_admin ───────────────
    private val MD_CODE = "KH01"

    // ─────────────────────────────────────────────────────────────────────────

    override fun onCreateView(inf: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val ctx = requireContext()
        dp = ctx.resources.displayMetrics.density

        // Root
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ctx.getColor(R.color.background))
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        // ── Toolbar ────────────────────────────────────────────────────────
        root.addView(LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(ctx.getColor(R.color.primary))
            setPadding(p(16), p(14), p(16), p(14))

            addView(TextView(ctx).apply {
                text = "🤖  AI HR Assistant"
                textSize = 17f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(ctx.getColor(R.color.white))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(TextView(ctx).apply {
                text = "Clear"
                textSize = 12f
                setTextColor(ctx.getColor(R.color.primary_ultra_light))
                setPadding(p(10), p(6), p(10), p(6))
                setOnClickListener { clearChat() }
            })
        })

        // ── Messages scroll area ───────────────────────────────────────────
        scrollView = ScrollView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        messagesContainer = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(p(12), p(12), p(12), p(12))
        }
        scrollView.addView(messagesContainer)
        root.addView(scrollView)

        // ── Input bar ──────────────────────────────────────────────────────
        root.addView(LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(ctx.getColor(R.color.surface))
            setPadding(p(10), p(8), p(10), p(8))
            elevation = 8f

            inputEt = EditText(ctx).apply {
                hint = "Ask anything… or tap mic"
                textSize = 14f
                setPadding(p(12), p(10), p(12), p(10))
                maxLines = 3
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .also { it.marginEnd = p(6) }
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(ctx.getColor(R.color.background))
                    cornerRadius = 20 * dp
                }
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) {
                        sendBtn.isEnabled = !s.isNullOrBlank()
                    }
                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                })
            }
            addView(inputEt)

            // Mic button — voice input like web
            val mb = MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "MIC"
                textSize = 11f
                setPadding(p(2), 0, p(2), 0)
                minWidth = p(44); minimumWidth = p(44)
                layoutParams = LinearLayout.LayoutParams(p(50), p(40))
                    .also { it.marginEnd = p(6) }
                setOnClickListener { toggleMic() }
            }
            micBtn = mb
            addView(mb)

            sendBtn = MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonStyle).apply {
                text = "Send"
                textSize = 13f
                setBackgroundColor(ctx.getColor(R.color.primary))
                isEnabled = false
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                setOnClickListener { onSend() }
            }
            addView(sendBtn)
        })

        // Init TTS — speak bot responses like web
        tts = TextToSpeech(ctx) { status ->
            ttsReady = (status == TextToSpeech.SUCCESS)
            if (ttsReady) {
                tts?.language = Locale("en", "IN")
                tts?.setSpeechRate(0.95f)
            }
        }

        // Show welcome message + quick chips
        showWelcome()

        return root
    }

    // ─────────────────────────────────────────────────────────────────────────
    // WELCOME
    // ─────────────────────────────────────────────────────────────────────────
    private fun showWelcome() {
        val sub = if (isManagerUp)
            "Ask me about your team's attendance, leave requests, contacts, or your own HR data."
        else
            "Ask me about your payslip, leaves, attendance, salary, or find a colleague's contact."

        addBotMsg("👋 **Hello, $userName!**\n\n$sub")

        // Quick-action chips
        val chips = mutableListOf(
            Chip("💳 My Payslip"),
            Chip("📅 Leave Balance"),
            Chip("🕐 My Attendance"),
            Chip("📞 HR Contact"),
            Chip("🗓 Plan Leave")
        )
        if (isManagerUp) {
            chips.add(0, Chip("👥 Team Today"))
            chips.add(1, Chip("✅ Pending Leaves"))
        }
        addChipRow(chips.take(6))
    }

    private fun clearChat() {
        messagesContainer.removeAllViews()
        chatHistory.clear()
        allEmployees = null
        leavePlan = null
        showWelcome()
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SEND / ROUTING
    // ─────────────────────────────────────────────────────────────────────────
    private fun onSend() {
        val query = inputEt.text.toString().trim()
        if (query.isBlank()) return
        inputEt.setText("")
        sendBtn.isEnabled = false
        addUserMsg(query)
        val thinking = addBotMsg("⏳ Thinking…", isThinking = true)
        lifecycleScope.launch {
            val response = withContext(Dispatchers.IO) { route(query) }
            withContext(Dispatchers.Main) {
                messagesContainer.removeView(thinking)
                renderBotResponse(response)
                sendBtn.isEnabled = true
                scrollToBottom()
            }
        }
    }

    private fun onChipTapped(chip: Chip) {
        if (chip.fragment != null) {
            (activity as? com.krishihr.app.ui.MainActivity)?.loadFragment(chip.fragment)
            return
        }
        inputEt.setText(chip.label.replace(Regex("^\\S+\\s"), ""))
        onSend()
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INTENT ROUTER
    // ─────────────────────────────────────────────────────────────────────────
    private suspend fun route(query: String): BotResponse {
        val lower = query.lowercase(Locale.getDefault())

        // Multi-turn leave planner
        if (leavePlan != null) {
            return handleLeavePlanStep(query, lower)
        }

        return when {
            // Payslip
            anyOf(lower, listOf("payslip","salary slip","pay slip","my salary","my pay")) ->
                handlePayslip()

            // Leave balance
            anyOf(lower, listOf("leave balance","leave left","remaining leave","how many leave","casual leave","earned leave","sick leave","privilege leave")) &&
                    !anyOf(lower, listOf("apply","plan","when","suggest")) ->
                handleLeaveBalance()

            // Leave history
            anyOf(lower, listOf("leave history","past leave","my leaves","applied leave","leave record")) ->
                handleLeaveHistory()

            // Attendance — team first (manager+)
            anyOf(lower, listOf("attendance","punch","check in","check out","present","absent")) && isManagerUp &&
                    !anyOf(lower, listOf("my attendance","my punch","personal")) ->
                handleTeamAttendance(lower)

            // Attendance — personal
            anyOf(lower, listOf("attendance","punch","check in","check out")) ->
                handleAttendance()

            // Team pending leaves (manager+)
            isManagerUp && anyOf(lower, listOf("team pending","pending leave","team leave","leave request","leave approval","approve leave")) ->
                handleTeamLeaveRequests()

            // Plan leave / suggest dates
            anyOf(lower, listOf("plan leave","suggest leave","best leave","when to take leave","take leave","apply leave","which day","holiday bridge")) ->
                startLeavePlanner()

            // HR/Key contacts
            isHRContactQuery(lower) ->
                handleHRContacts(lower)

            // Employee directory
            isEmployeeQuery(lower) ->
                handleEmployeeDir(query)

            // Fallback to Claude
            else -> handleWithClaude(query)
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PAYSLIP
    // ─────────────────────────────────────────────────────────────────────────
    private suspend fun handlePayslip(): BotResponse {
        return try {
            val res = RetrofitClient.instance.getPayroll()
            val payrolls = res.body()?.data ?: emptyList()
            if (payrolls.isEmpty()) return BotResponse("No payslip data found yet. Check back after payroll is processed.")
            val latest = payrolls.first()
            val month = latest.month?.let { m ->
                val months = listOf("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
                months.getOrNull((m - 1).coerceIn(0, 11))
            } ?: "—"
            val year  = latest.year ?: "—"
            val net   = "₹${formatAmount(latest.effectiveNet)}"
            val gross = "₹${formatAmount(latest.effectiveGross)}"
            val ded   = "₹${formatAmount(latest.effectiveDed)}"
            BotResponse(
                "💳 **Payslip — $month $year**\n\n" +
                        "Gross Pay: **$gross**\n" +
                        "Deductions: **$ded**\n" +
                        "**Net Pay: $net**",
                listOf(Chip("📄 View Full Payslip", com.krishihr.app.ui.payroll.PayrollFragment()))
            )
        } catch (e: Exception) {
            BotResponse("Could not load payslip. Please try again.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LEAVE BALANCE
    // ─────────────────────────────────────────────────────────────────────────
    private suspend fun handleLeaveBalance(): BotResponse {
        return try {
            val res = RetrofitClient.instance.getLeaveBalance()
            val balances = res.body()?.data ?: emptyList()
            if (balances.isEmpty()) return BotResponse("No leave balance data available.")
            val lines = balances.map { b ->
                val used  = b.used
                val bal   = b.balance
                val total = used + bal
                "**${b.leaveTypeName ?: b.effectiveName}**: ${bal.toInt()} remaining (${used.toInt()} used of ${total.toInt()})"
            }
            BotResponse("📅 **Your Leave Balance**\n\n${lines.joinToString("\n")}", listOf(Chip("📋 Apply Leave", com.krishihr.app.ui.leave.LeaveFragment())))
        } catch (e: Exception) {
            BotResponse("Could not load leave balance.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LEAVE HISTORY
    // ─────────────────────────────────────────────────────────────────────────
    private suspend fun handleLeaveHistory(): BotResponse {
        return try {
            val res = RetrofitClient.instance.getLeaveApplications(null)
            val leaves = (res.body()?.data ?: emptyList()).take(5)
            if (leaves.isEmpty()) return BotResponse("No leave history found.")
            val lines = leaves.map { l ->
                val from = l.fromDate?.take(10)?.toDisplayDate() ?: "—"
                val to   = l.toDate?.take(10)?.toDisplayDate() ?: "—"
                val status = l.status?.replaceFirstChar { it.uppercase() } ?: "—"
                "• ${l.leaveTypeName ?: "Leave"}: $from → $to ($status)"
            }
            BotResponse("📜 **Recent Leaves**\n\n${lines.joinToString("\n")}", listOf(Chip("📋 View All Leaves", com.krishihr.app.ui.leave.LeaveFragment())))
        } catch (e: Exception) {
            BotResponse("Could not load leave history.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ATTENDANCE — personal
    // ─────────────────────────────────────────────────────────────────────────
    private suspend fun handleAttendance(): BotResponse {
        return try {
            val res = RetrofitClient.instance.getDashboard()
            val att = res.body()?.data?.todayAttendance
            val punchIn  = att?.displayPunchIn ?: "—"
            val punchOut = att?.displayPunchOut ?: "—"
            val status   = att?.status?.replaceFirstChar { it.uppercase() } ?: "Not marked"
            val hours    = att?.workingHours?.let { h -> "${h}h worked" } ?: ""
            BotResponse("🕐 **Today's Attendance**\n\nStatus: **$status**\nPunch In: **$punchIn**\nPunch Out: **$punchOut**${if (hours.isNotBlank()) "\n$hours" else ""}")
        } catch (e: Exception) {
            BotResponse("Could not load attendance data.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ATTENDANCE — team (manager+)
    // ─────────────────────────────────────────────────────────────────────────
    private suspend fun handleTeamAttendance(lower: String): BotResponse {
        return try {
            val res = RetrofitClient.instance.getTeamToday()
            val team = res.body()?.data ?: emptyList()
            if (team.isEmpty()) return BotResponse("No team attendance data found.")
            val present = team.count { it.status?.lowercase() in listOf("present","late","wfh","od") }
            val absent  = team.count { it.status?.lowercase() == "absent" }
            val lines = team.take(8).map { t ->
                val s = t.status?.replaceFirstChar { it.uppercase() } ?: "—"
                val `in` = t.punchIn?.take(5) ?: "--"
                "• ${t.employeeName ?: "—"}: $s (in: ${`in`})"
            }
            val more = if (team.size > 8) "\n…and ${team.size - 8} more" else ""
            BotResponse(
                "👥 **Team Attendance Today** (${team.size} members)\n\n" +
                        "Present: **$present** | Absent: **$absent**\n\n" +
                        lines.joinToString("\n") + more
            )
        } catch (e: Exception) {
            BotResponse("Could not load team attendance.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TEAM LEAVE REQUESTS
    // ─────────────────────────────────────────────────────────────────────────
    private suspend fun handleTeamLeaveRequests(): BotResponse {
        return try {
            val myId = user?.id
            val res = RetrofitClient.instance.getLeaveApplications("pending")
            val pending = (res.body()?.data ?: emptyList()).filter { it.employeeId != myId }
            if (pending.isEmpty()) return BotResponse("✅ No pending leave requests from your team.")
            val lines = pending.take(6).map { l ->
                val from = l.fromDate?.take(10)?.toDisplayDate() ?: "—"
                val to   = l.toDate?.take(10)?.toDisplayDate() ?: "—"
                "• ${l.employeeName ?: "—"}: ${l.leaveTypeName ?: "Leave"} ($from → $to)"
            }
            val more = if (pending.size > 6) "\n…+${pending.size - 6} more" else ""
            BotResponse(
                "📋 **${pending.size} Pending Leave Request${if (pending.size > 1) "s" else ""}**\n\n${lines.joinToString("\n")}$more",
                listOf(Chip("✅ Review Requests", ApprovalsFragment()))
            )
        } catch (e: Exception) {
            BotResponse("Could not load pending leave requests.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // LEAVE PLANNER — multi-turn
    // ─────────────────────────────────────────────────────────────────────────
    private suspend fun startLeavePlanner(): BotResponse {
        return try {
            val res = RetrofitClient.instance.getLeaveBalance()
            val usable = (res.body()?.data ?: emptyList()).filter { it.balance > 0.0 }
            if (usable.isEmpty()) return BotResponse("You don't have any leave balance available to plan right now.")
            leavePlan = LeavePlan(
                step = "type",
                types = usable.mapIndexed { i, b -> LeaveType(b.leaveTypeId ?: (i + 1), b.leaveTypeName ?: b.name ?: "Leave") }
            )
            val list = leavePlan!!.types.mapIndexed { i, t -> "${i + 1}. ${t.name}" }.joinToString("\n")
            BotResponse("🗓 **Leave Planner**\n\nWhich type of leave do you want to plan?\n\n$list\n\nReply with the number or name.")
        } catch (e: Exception) {
            BotResponse("Could not load leave types.")
        }
    }

    private suspend fun handleLeavePlanStep(query: String, lower: String): BotResponse {
        val plan = leavePlan ?: return startLeavePlanner()

        if (plan.step == "type") {
            val idx = lower.trim().firstOrNull()?.digitToIntOrNull()
            val picked = if (idx != null && idx > 0) plan.types.getOrNull(idx - 1)
            else plan.types.find { lower.contains(it.name.lowercase()) }
            if (picked == null) {
                return BotResponse("I didn't catch that. Please reply with the number of the leave type:\n\n" +
                        plan.types.mapIndexed { i, t -> "${i + 1}. ${t.name}" }.joinToString("\n"))
            }
            leavePlan = plan.copy(step = "days", leaveTypeId = picked.id, leaveTypeName = picked.name)
            return BotResponse("How many days of **${picked.name}** do you want to take?")
        }

        if (plan.step == "days") {
            val num = Regex("\\d+").find(lower)?.value?.toIntOrNull()
            if (num == null || num < 1) {
                leavePlan = null
                return BotResponse("That doesn't look like a valid number of days. Let's start over — say \"plan leave\" again.")
            }

            // Check balance
            return try {
                val balRes = RetrofitClient.instance.getLeaveBalance()
                val balRow = balRes.body()?.data?.find { it.leaveTypeId == plan.leaveTypeId || (it.leaveTypeName ?: it.effectiveName) == plan.leaveTypeName }
                val remaining = balRow?.balance?.toInt() ?: 0
                if (num > remaining) {
                    leavePlan = null
                    return BotResponse("⚠️ You only have **$remaining day${if (remaining != 1) "s" else ""}** of ${plan.leaveTypeName} left, but you want **$num days**.\n\nPlease apply for fewer days, or contact HR to adjust your balance.")
                }
                leavePlan = plan.copy(step = "suggest", days = num)
                suggestLeaveDates(plan.copy(days = num))
            } catch (e: Exception) {
                leavePlan = null
                BotResponse("Could not verify leave balance. Please try again.")
            }
        }

        // Unknown step — reset
        leavePlan = null
        return BotResponse("Something went wrong. Say \"plan leave\" to start over.")
    }

    private suspend fun suggestLeaveDates(plan: LeavePlan): BotResponse {
        leavePlan = null
        val days = plan.days
        val leaveTypeName = plan.leaveTypeName

        return try {
            // Fetch holidays
            val holidayRes = RetrofitClient.instance.getHolidays()
            val holidays = (holidayRes.body()?.data ?: emptyList()).mapNotNull { it.date?.take(10) }.toSet()

            // Fetch team leaves to detect team conflicts
            val teamRes = try { RetrofitClient.instance.getLeaveApplications("approved") } catch (_: Exception) { null }
            val teamLeaves = (teamRes?.body()?.data ?: emptyList())
                .filter { it.employeeId != user?.id }
                .flatMap { l ->
                    dateRange(l.fromDate?.take(10), l.toDate?.take(10))
                }

            // Build candidates — next 60 working days
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val cal = Calendar.getInstance()
            val today = sdf.format(cal.time)

            data class Candidate(val start: String, val end: String, var score: Int = 0, var maxTeam: Int = 0)

            val candidates = mutableListOf<Candidate>()

            outer@ for (offset in 1..90) {
                cal.time = sdf.parse(today)!!
                cal.add(Calendar.DAY_OF_MONTH, offset)
                if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) continue

                // Build window of `days` working days
                val window = mutableListOf<String>()
                val wCal = cal.clone() as Calendar
                var attempts = 0
                while (window.size < days && attempts < 30) {
                    val ds = sdf.format(wCal.time)
                    val dow = wCal.get(Calendar.DAY_OF_WEEK)
                    if (dow != Calendar.SATURDAY && dow != Calendar.SUNDAY && !holidays.contains(ds)) {
                        window.add(ds)
                    }
                    wCal.add(Calendar.DAY_OF_MONTH, 1)
                    attempts++
                }
                if (window.size < days) continue

                val startStr = window.first()
                val endStr   = window.last()
                var score    = 0

                // Score: bridges into weekend (ends Friday)
                val endCal = Calendar.getInstance().also { it.time = sdf.parse(endStr)!! }
                if (endCal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) score += 60

                // Score: bridges from weekend (starts Monday)
                val startCal = Calendar.getInstance().also { it.time = sdf.parse(startStr)!! }
                if (startCal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) score += 20

                // Score: holiday adjacent
                val dayBefore = adjacentDay(startStr, -1, sdf)
                val dayAfter  = adjacentDay(endStr, +1, sdf)
                if (holidays.contains(dayBefore)) score += 35
                if (holidays.contains(dayAfter))  score += 35

                // Score: holiday in window
                val holsInWindow = window.count { holidays.contains(it) }
                score += holsInWindow * 15

                // Team conflict count
                val maxTeam = window.maxOfOrNull { d -> teamLeaves.count { it == d } } ?: 0
                if (maxTeam > 2) score -= 30

                candidates.add(Candidate(startStr, endStr, score, maxTeam))
            }

            // Sort by score desc, deduplicate by start
            val seen = mutableSetOf<String>()
            val best = candidates.sortedByDescending { it.score }.filter { seen.add(it.start) }.take(3)

            if (best.isEmpty()) {
                return BotResponse("Couldn't find suitable dates for $days days of $leaveTypeName in the next 3 months. Try a shorter duration.")
            }

            // Build balance note
            val balRes = try { RetrofitClient.instance.getLeaveBalance() } catch (_: Exception) { null }
            val balRow = balRes?.body()?.data?.find { it.leaveTypeId == plan.leaveTypeId || (it.leaveTypeName ?: it.effectiveName) == leaveTypeName }
            val remaining = balRow?.balance?.toInt()
            val balNote = if (remaining != null) "\n💰 You have **$remaining days** of $leaveTypeName remaining." else ""

            val labels = listOf("🥇 Option 1", "🥈 Option 2", "🥉 Option 3")
            var text = "📅 **Best dates for your $days-day $leaveTypeName**$balNote\n\n"

            best.forEachIndexed { i, c ->
                val fs = sdf.parse(c.start)?.toDisplayDate() ?: c.start
                val fe = sdf.parse(c.end)?.toDisplayDate() ?: c.end
                val label = labels.getOrElse(i) { "Option ${i + 1}" }
                val warn = if (c.maxTeam > 0) " ⚠️ ${c.maxTeam} teammate${if (c.maxTeam > 1) "s" else ""} on leave" else " ✅ Team all clear"
                text += "**$label**\n$fs → $fe$warn\n\n"
            }
            text += "\nReady to apply? Head to Leaves and use one of these windows! 😊"

            BotResponse(text, listOf(Chip("📋 Apply Leave", com.krishihr.app.ui.leave.LeaveFragment())))
        } catch (e: Exception) {
            BotResponse("Could not calculate leave suggestions. Please try again.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // HR / KEY CONTACTS
    // ─────────────────────────────────────────────────────────────────────────
    private fun isHRContactQuery(lower: String): Boolean = anyOf(lower, listOf(
        "hr contact","get hr","hr details","hr team","hr person","hr number","hr email",
        "accounts contact","accounts team","accounts details","accounts number","get accounts",
        "reporting manager","my manager","who is my manager","manager contact","manager details",
        "contact hr","contact accounts","reach hr","reach accounts",
        "i want to get hr","want hr contact","need hr contact","show hr contact",
        "hr and accounts","key contacts","important contacts",
        "who to contact","who should i contact","escalate","escalation contact"
    ))

    private suspend fun handleHRContacts(lower: String): BotResponse {
        val wantsAccounts = anyOf(lower, listOf("accounts contact","accounts team","accounts details","accounts number","accounts email","contact accounts","reach accounts","get accounts","want accounts","need accounts","show accounts"))
        val wantsHR       = anyOf(lower, listOf("hr contact","get hr","hr details","hr team","hr person","hr number","hr email","contact hr","reach hr","i want to get hr","want hr contact","need hr contact","show hr contact","find hr"))
        val wantsManager  = anyOf(lower, listOf("reporting manager","my manager","who is my manager","manager contact","manager details","find manager","get manager","show manager","manager number","manager email"))
        val wantsBoth     = anyOf(lower, listOf("hr and accounts","hr account contact","key contacts","important contacts","who to contact","who should i contact","escalate","escalation contact"))

        val showHR       = wantsBoth || wantsHR
        val showAccounts = wantsBoth || wantsAccounts
        val showManager  = wantsBoth || wantsManager
        val showDefault  = !showHR && !showAccounts && !showManager

        var hrTeam = emptyList<EmployeeContact>()
        var accountsTeam = emptyList<EmployeeContact>()
        var reportingManager: EmployeeContact? = null

        if (isPrivAdmin) {
            // Full employee list for admins/HR/accounts
            val allEmp = loadAllEmployees() ?: return BotResponse("Could not load contact directory.")
            hrTeam = if (showHR || showDefault) allEmp.filter { it.role == "hr" } else emptyList()
            accountsTeam = if (showAccounts) allEmp.filter { it.role == "accounts" } else emptyList()
            if (showManager) {
                val myEmp = allEmp.find { it.employeeCode == user?.employeeCode }
                reportingManager = myEmp?.reportingManagerId?.let { mgrId ->
                    allEmp.find { it.id == mgrId && it.role != "super_admin" }
                }
            }
        } else {
            // Restricted endpoint for employees/managers
            if (showHR || showDefault) {
                hrTeam = loadContacts("hr")
            }
            if (showAccounts) {
                accountsTeam = loadContacts("accounts")
            }
            if (showManager) {
                val mgrId = user?.reportingManagerId
                if (mgrId != null && mgrId > 0) {
                    reportingManager = loadContacts("manager", mgrId).firstOrNull()
                }
            }
        }

        var text = ""
        if (hrTeam.isNotEmpty()) {
            text += "🧑‍💼 **HR Team**\n" + hrTeam.joinToString("\n") { c -> formatContact(c) } + "\n\n"
        }
        if (accountsTeam.isNotEmpty()) {
            text += "💼 **Accounts Team**\n" + accountsTeam.joinToString("\n") { c -> formatContact(c) } + "\n\n"
        }
        if (reportingManager != null) {
            text += "📋 **Reporting Manager**\n" + formatContact(reportingManager) + "\n\n"
        } else if (showManager) {
            text += "📋 **Reporting Manager**: Not assigned — contact HR to update.\n\n"
        }

        if (text.isBlank()) return BotResponse("Sorry $userName, no contacts found. Try asking for \"HR contact\" or \"Accounts contact\".")
        return BotResponse(text.trim())
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EMPLOYEE DIRECTORY
    // ─────────────────────────────────────────────────────────────────────────
    private fun isEmployeeQuery(lower: String): Boolean {
        if (anyOf(lower, listOf("find employee","find colleague","contact of","phone of","email of","number of",
                "who is ","reach ","contact details","directory","employee details","find ","search employee",
                "details of","detail of","want to find","looking for","info of","information of",
                "get details","show details","employee contact","colleague contact"))) return true
        if (role == Roles.SUPER_ADMIN && anyOf(lower, listOf("get ","show ","search "))) {
            val skip = listOf("get hr","get leave","get salary","get payslip","get attendance","show leave","show salary","show team")
            if (skip.none { lower.startsWith(it) || lower.contains(it) }) return true
        }
        return false
    }

    private suspend fun handleEmployeeDir(query: String): BotResponse {
        val stopWords = setOf("find","employee","employees","colleague","contact","of","the","phone",
            "email","number","details","detail","who","is","reach","search","me","please","can","you",
            "get","show","i","want","to","a","an","my","your","their","his","her","for","with",
            "about","looking","info","information","tell","give","need","check","see")
        val tokens = query.lowercase().split("\\s+".toRegex())
            .filter { it.length > 1 && !stopWords.contains(it) }
        val searchTerm = tokens.joinToString(" ").trim()

        if (searchTerm.isBlank()) return BotResponse("Sure! Tell me the name of the colleague you're looking for. For example: \"Find Rahul Sharma\"")

        val allEmp = loadAllEmployees() ?: return BotResponse("Could not load employee directory.")

        val results = allEmp.filter { e ->
            val fullName = "${e.firstName} ${e.lastName}".lowercase()
            fullName.contains(searchTerm) ||
                    e.employeeCode?.lowercase()?.contains(searchTerm) == true ||
                    e.designationTitle?.lowercase()?.contains(searchTerm) == true ||
                    e.departmentName?.lowercase()?.contains(searchTerm) == true ||
                    (searchTerm.length >= 3 && (e.firstName.lowercase().startsWith(searchTerm) || e.lastName.lowercase().startsWith(searchTerm)))
        }.filter { it.isActive }

        if (results.isEmpty()) return BotResponse("No employee found matching \"$searchTerm\". Try a different name or department.")

        // Block MD contact — super_admin can see everyone
        val isSuperAdmin = role == Roles.SUPER_ADMIN
        val shown   = if (isSuperAdmin) results.take(6) else results.filter { it.employeeCode != MD_CODE }.take(4)
        val blocked = results.any { it.employeeCode == MD_CODE }

        if (shown.isEmpty() && blocked) return BotResponse("I'm sorry, I can't share contact details for the Managing Director.")

        val countText = if (shown.size == 1) "Here's the contact info for **${shown[0].firstName} ${shown[0].lastName}**:"
        else "Found ${shown.size} match${if (shown.size > 1) "es" else ""}:"

        val contacts = shown.joinToString("\n\n") { formatContact(it) }
        return BotResponse("$countText\n\n$contacts")
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CLAUDE FALLBACK
    // ─────────────────────────────────────────────────────────────────────────
    private suspend fun handleWithClaude(query: String): BotResponse {
        val systemPrompt = "You are a helpful HR assistant for ${AndroidMain.COMPANY_NAME}. Employee: $userName ($role).\n" +
                "Reply in 2-4 sentences max. Use plain text. No markdown symbols.\n" +
                "Be warm and professional. Suggest relevant sections if you can't fetch specific data.\n" +
                "IMPORTANT: If you cannot answer from HR data context, respond ONLY with the single word: UNKNOWN"

        chatHistory.add(JSONObject().apply { put("role", "user"); put("content", query) })
        if (chatHistory.size > 12) repeat(chatHistory.size - 12) { chatHistory.removeAt(0) }

        return try {
            val body = JSONObject().apply {
                put("model", "claude-sonnet-4-20250514")
                put("max_tokens", 400)
                put("system", systemPrompt)
                put("messages", JSONArray(chatHistory.map { it.toString() }))
            }
            val reply = callClaude(body)
            chatHistory.add(JSONObject().apply { put("role", "assistant"); put("content", reply) })

            if (reply.isBlank() || reply.trim().uppercase() == "UNKNOWN") {
                buildUnknownResponse()
            } else {
                BotResponse(reply)
            }
        } catch (e: Exception) {
            buildUnknownResponse()
        }
    }

    private suspend fun buildUnknownResponse(): BotResponse {
        // Try to find Akshay Rai's contact — admins use full list, others use contacts endpoint
        var contactLine = ""
        return try {
            val searchPool = if (isPrivAdmin) {
                loadAllEmployees() ?: emptyList()
            } else {
                loadContacts("admin")
            }
            val akshay = searchPool.find { e ->
                "${e.firstName} ${e.lastName}".lowercase().contains("akshay rai")
            }
            if (akshay != null) {
                contactLine = "Please register your query with ${akshay.firstName} ${akshay.lastName} so they can update the system for you.\n\n${formatContact(akshay)}"
            }
            BotResponse("I'm currently in trial version and this query hasn't been configured yet. $contactLine".trim())
        } catch (_: Exception) {
            BotResponse("I'm currently in trial version and this query hasn't been configured yet.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DATA HELPERS
    // ─────────────────────────────────────────────────────────────────────────
    private suspend fun loadAllEmployees(): List<EmployeeContact>? {
        if (allEmployees != null) return parseEmployeeArray(allEmployees!!)
        return try {
            val res = RetrofitClient.instance.getEmployees()
            if (res.isSuccessful && res.body()?.success == true) {
                val arr = JSONArray(com.google.gson.Gson().toJson(res.body()?.data ?: emptyList<Any>()))
                allEmployees = arr
                parseEmployeeArray(arr)
            } else null
        } catch (_: Exception) { null }
    }

    private suspend fun loadContacts(type: String, managerId: Int? = null): List<EmployeeContact> {
        return try {
            val url = "contacts?type=$type${if (managerId != null) "&manager_id=$managerId" else ""}"
            val res = RetrofitClient.instance.getEmployeeContacts(type, managerId)
            res.body()?.data?.map { e ->
                EmployeeContact(
                    id = e.id,
                    employeeCode = e.employeeCode,
                    firstName = e.firstName ?: "",
                    lastName = e.lastName ?: "",
                    role = e.role ?: "",
                    phone = e.phone,
                    email = e.email ?: "",
                    designationTitle = e.designationTitle,
                    departmentName = e.departmentName,
                    isActive = e.isActive != false,
                    reportingManagerId = null
                )
            } ?: emptyList()
        } catch (_: Exception) { emptyList() }
    }

    private fun parseEmployeeArray(arr: JSONArray): List<EmployeeContact> {
        val result = mutableListOf<EmployeeContact>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            result.add(EmployeeContact(
                id = obj.optInt("id"),
                employeeCode = obj.optString("employee_code").ifBlank { null },
                firstName = obj.optString("first_name", ""),
                lastName  = obj.optString("last_name", ""),
                role      = obj.optString("role", "employee"),
                phone     = obj.optString("phone").ifBlank { null },
                email     = obj.optString("email", ""),
                designationTitle = obj.optString("designation_title").ifBlank { null },
                departmentName   = obj.optString("department_name").ifBlank { null },
                isActive  = obj.optBoolean("is_active", true),
                reportingManagerId = obj.optInt("reporting_manager_id").takeIf { it > 0 }
            ))
        }
        return result
    }

    data class EmployeeContact(
        val id: Int,
        val employeeCode: String?,
        val firstName: String,
        val lastName: String,
        val role: String,
        val phone: String?,
        val email: String,
        val designationTitle: String?,
        val departmentName: String?,
        val isActive: Boolean,
        val reportingManagerId: Int?
    )

    private fun formatContact(e: EmployeeContact): String {
        val name = "${e.firstName} ${e.lastName}"
        val desg = e.designationTitle ?: e.departmentName ?: ""
        val ph   = e.phone?.let { "📞 $it" } ?: ""
        val em   = if (e.email.isNotBlank()) "✉️ ${e.email}" else ""
        return "**$name**${if (desg.isNotBlank()) " · $desg" else ""}\n${listOf(ph, em).filter { it.isNotBlank() }.joinToString("  ")}"
    }

    private suspend fun callClaude(body: JSONObject): String = withContext(Dispatchers.IO) {
        val url = URL("https://api.anthropic.com/v1/messages")
        val conn = url.openConnection() as HttpsURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.connectTimeout = 15_000
        conn.readTimeout    = 30_000
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = conn.inputStream.bufferedReader().readText()
        val json = JSONObject(resp)
        json.getJSONArray("content").getJSONObject(0).getString("text")
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UI HELPERS
    // ─────────────────────────────────────────────────────────────────────────
    private fun addUserMsg(text: String): View {
        val ctx = requireContext()
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.bottomMargin = p(10) }
        }
        row.addView(TextView(ctx).apply {
            this.text = text; textSize = 14f
            setTextColor(ctx.getColor(R.color.white))
            setBackgroundColor(ctx.getColor(R.color.primary))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(ctx.getColor(R.color.primary)); cornerRadius = 16 * dp
            }
            setPadding(p(12), p(10), p(12), p(10))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.marginStart = p(60) }
        })
        messagesContainer.addView(row)
        scrollToBottom()
        return row
    }

    private fun addBotMsg(text: String, isThinking: Boolean = false): View {
        val ctx = requireContext()
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.START
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.bottomMargin = p(10) }
        }
        // Avatar
        val avCard = androidx.cardview.widget.CardView(ctx).apply {
            radius = p(16).toFloat(); cardElevation = 0f
            setCardBackgroundColor(ctx.getColor(R.color.primary))
            layoutParams = LinearLayout.LayoutParams(p(32), p(32)).also { it.marginEnd = p(8); it.topMargin = p(2) }
        }
        avCard.addView(TextView(ctx).apply {
            this.text = "🤖"; textSize = 14f; gravity = Gravity.CENTER
            layoutParams = android.widget.FrameLayout.LayoutParams(android.widget.FrameLayout.LayoutParams.MATCH_PARENT, android.widget.FrameLayout.LayoutParams.MATCH_PARENT)
        })
        row.addView(avCard)

        // Bubble
        val bubble = TextView(ctx).apply {
            this.text = renderMarkdown(text); textSize = 14f
            setTextColor(ctx.getColor(R.color.text_primary))
            setBackgroundColor(ctx.getColor(R.color.surface))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(ctx.getColor(R.color.surface)); cornerRadius = 16 * dp
            }
            setPadding(p(12), p(10), p(12), p(10))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .also { it.marginEnd = p(40) }
            if (isThinking) setTextColor(ctx.getColor(R.color.text_hint))
        }
        row.addView(bubble)
        messagesContainer.addView(row)
        scrollToBottom()
        return row
    }

    private fun renderBotResponse(response: BotResponse) {
        addBotMsg(response.text)
        if (response.chips.isNotEmpty()) addChipRow(response.chips)
        // Speak the response like the web version
        speakTTS(response.text)
    }

    private fun addChipRow(chips: List<Chip>) {
        val ctx = requireContext()
        val hScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { it.bottomMargin = p(10) }
        }
        val chipRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(p(40), 0, p(8), 0)
        }
        chips.forEach { chip ->
            chipRow.addView(MaterialButton(ctx, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = chip.label; textSize = 12f
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .also { it.marginEnd = p(6) }
                setOnClickListener { onChipTapped(chip) }
            })
        }
        hScroll.addView(chipRow)
        messagesContainer.addView(hScroll)
        scrollToBottom()
    }

    private fun scrollToBottom() {
        scrollView.post { scrollView.fullScroll(View.FOCUS_DOWN) }
    }

    // Simple bold markdown: **text** → bold spans
    private fun renderMarkdown(text: String): android.text.SpannableString {
        val sb = StringBuilder()
        val spans = mutableListOf<Triple<Int, Int, Any>>()
        var i = 0
        while (i < text.length) {
            if (i + 1 < text.length && text[i] == '*' && text[i+1] == '*') {
                val end = text.indexOf("**", i + 2)
                if (end != -1) {
                    val start = sb.length
                    sb.append(text.substring(i + 2, end))
                    spans.add(Triple(start, sb.length, android.graphics.Typeface.BOLD))
                    i = end + 2
                    continue
                }
            }
            sb.append(text[i]); i++
        }
        val spannable = android.text.SpannableString(sb)
        spans.forEach { (s, e, _) ->
            spannable.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), s, e, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return spannable
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MIC + TTS — mirrors ai-voice.html speech features
    // ─────────────────────────────────────────────────────────────────────────

    private fun toggleMic() {
        if (!SpeechRecognizer.isRecognitionAvailable(requireContext())) {
            toast("Speech recognition not available on this device")
            return
        }
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
            return
        }
        if (isListening) {
            stopListening()
        } else {
            startListening()
        }
    }

    private fun startListening() {
        val ctx = requireContext()
        tts?.stop()

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(ctx)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {
                isListening = true
                micBtn?.text = "STOP"
                micBtn?.setBackgroundColor(ctx.getColor(R.color.accent_red))
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                micBtn?.text = "MIC"
                micBtn?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim() ?: return
                inputEt.setText(text)
                sendBtn.isEnabled = text.isNotBlank()
                if (text.isNotBlank()) onSend()
            }
            override fun onError(error: Int) {
                isListening = false
                micBtn?.text = "MIC"
                micBtn?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH    -> "No speech detected"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Timed out"
                    SpeechRecognizer.ERROR_AUDIO       -> "Audio error"
                    SpeechRecognizer.ERROR_NETWORK     -> "Network error"
                    else -> "Speech error ($error)"
                }
                toast(msg)
            }
            override fun onPartialResults(partial: Bundle?) {
                val matches = partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val interim = matches?.firstOrNull() ?: return
                inputEt.setText(interim)
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { speechRecognizer?.startListening(intent) }
        catch (e: Exception) { toast("Could not start mic: ${e.message}") }
    }

    private fun stopListening() {
        speechRecognizer?.stopListening()
        isListening = false
        micBtn?.text = "MIC"
        micBtn?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
    }

    private fun speakTTS(text: String) {
        if (!ttsReady || tts == null) return
        // Strip markdown bold
        val clean = text
            .replace(Regex("\\*\\*(.+?)\\*\\*"), "$1")
            .replace(Regex("\\*(.+?)\\*"), "$1")
            .replace("\n", ". ")
            .replace(Regex("\\s{2,}"), " ")
            .trim()
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "ai_response")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        tts?.stop(); tts?.shutdown(); tts = null
        speechRecognizer?.destroy(); speechRecognizer = null
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == 1001) {
            toast("Microphone permission required for voice input")
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UTILITIES
    // ─────────────────────────────────────────────────────────────────────────
    private fun anyOf(str: String, keywords: List<String>) = keywords.any { str.contains(it) }
    private fun p(dp: Int) = (dp * this.dp).toInt()
    private fun formatAmount(v: Number) = "%,.0f".format(v.toDouble())

    private fun dateRange(from: String?, to: String?): List<String> {
        if (from == null || to == null) return emptyList()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val result = mutableListOf<String>()
        val cal = Calendar.getInstance().also { it.time = sdf.parse(from) ?: return emptyList() }
        val endTime = sdf.parse(to)?.time ?: return emptyList()
        while (cal.timeInMillis <= endTime) {
            result.add(sdf.format(cal.time))
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        return result
    }

    private fun adjacentDay(dateStr: String, offset: Int, sdf: SimpleDateFormat): String {
        val cal = Calendar.getInstance().also { it.time = sdf.parse(dateStr) ?: return "" }
        cal.add(Calendar.DAY_OF_MONTH, offset)
        // Skip weekends for adjacency
        while (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
            cal.add(Calendar.DAY_OF_MONTH, if (offset > 0) 1 else -1)
        }
        return sdf.format(cal.time)
    }

    private fun String.toDisplayDate(): String {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val out = SimpleDateFormat("EEE, d MMM", Locale.getDefault())
            out.format(sdf.parse(this) ?: return this)
        } catch (_: Exception) { this }
    }

    private fun Date.toDisplayDate(): String {
        return SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(this)
    }
}